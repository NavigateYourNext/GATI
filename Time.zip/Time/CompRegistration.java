package net.codejava;

public class CompRegistration 
{

	int regno;
	String from;
	String query;
	
	public int getRegno() 
	{
		return regno;
	}
	public void setRegno(int regno) 
	{
		this.regno = regno;
	}
	public String getFrom() 
	{
		return from;
	}
	public void setFrom(String from) 
	{
		this.from = from;
	}
	public String getQuery() 
	{
		return query;
	}
	public void setQuery(String query)
	{
		this.query = query;
	}
	
	

}
